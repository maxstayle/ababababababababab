﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class ProgramTests
    {
        [TestMethod]
        public void FixWrongResult_ValidInput_ReturnsUnchangedFraction()
        {
            // Arrange
            string input = "1/10";

            // Act
            string result = Program.FixWrongResult(input);

            // Assert
            Assert.AreEqual(input, result);
        }

        [TestMethod]
        public void FixWrongResult_FractionToFix_ReturnsFixedFraction()
        {
            // Arrange
            string input = "251/100";

            // Act
            string result = Program.FixWrongResult(input);

            // Assert
            Assert.AreEqual("100/100", result);
        }

        [TestMethod]
        public void FixWrongResult_NegativeFraction_ReturnsUnchangedFraction()
        {
            // Arrange
            string input = "-10/10";

            // Act
            string result = Program.FixWrongResult(input);

            // Assert
            Assert.AreEqual(input, result);
        }

        [TestMethod]
        [ExpectedException(typeof(System.ArgumentException))]
        public void FixWrongResult_InvalidInput_ThrowsException()
        {
            // Arrange
            string input = "35/10/10/25";

            // Act
            string result = Program.FixWrongResult(input);

            // Assert
            // The test method expects an exception, so there's no explicit assertion needed here.
        }
    }
}
