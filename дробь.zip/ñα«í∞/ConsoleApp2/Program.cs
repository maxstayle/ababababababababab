﻿using System;

public class Program
{
    public static void Main()
    {
        try
        {
            Console.WriteLine("Введите дробь в формате ЧИСЛО1/ЧИСЛО2:");
            string input = Console.ReadLine();

            string result = FixWrongResult(input);

            Console.WriteLine($"Исходная дробь: {input}");
            Console.WriteLine($"Исправленный результат: {result}");

            // Добавим ожидание ввода перед закрытием приложения
            Console.WriteLine("Нажмите Enter для выхода...");
            Console.ReadLine();
        }
        catch (ArgumentException ex)
        {
            Console.WriteLine($"Exception: {ex.Message}");
        }
    }

    public static string FixWrongResult(string text)
    {
        if (string.IsNullOrEmpty(text) || !text.Contains("/") || text.Split('/').Length != 2)
        {
            throw new ArgumentException("Некорректный ввод");
        }

        string[] parts = text.Split(',');
        if (int.TryParse(parts[0], out int num1) && int.TryParse(parts[1], out int num2))
        {
            if (num1 > num2)
            {
                return $"{num2}/{num2}";
            }

            return text;
        }

        throw new ArgumentException("Некорректный ввод");
    }
}
